Use `db_scope_search.ipynb`. If you have comments or suggestions please leave an issue

Changes 07/15
- database indecies added for `AllWISE___id`, `Gaia_EDR3___id` and `PS1_DR1___id`
- Added seperate username and passwords for each host